﻿Organization chart example for Graph Modeler
============================================

An org chart drawn from a spreadsheet of employees, with the SQL tab walking the reporting lines.
The employees are made up; any resemblance to a real person is chance.

Files
- org-chart.json: the Graph Modeler project.
- employee-data.xlsx: the data the project's SQL reads.
- org-chart-knowledge-graph.json: the Knowledge Graph (JSON) of the diagram, as made by the Knowledge Graph tab of Graph Modeler 1.0.1 or later.

How to open it
1. Keep the project and the spreadsheet together in one folder.
2. In Graph Modeler, choose Open and pick org-chart.json.
3. The Diagram tab shows the chart, and the Knowledge Graph tab the same graph as JSON. On the SQL tab, Run SQL builds the rows again from the spreadsheet.
   Change the placeholders at the top of the SQL tab (id_number, max_down, max_up) to chart another person.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
The full write-up of this example: https://graphmodeler.com/examples/org-chart-from-a-spreadsheet/
