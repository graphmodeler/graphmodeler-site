﻿Org chart from a spreadsheet
============================
An organization chart centered on one employee, drawn with tree queries. The employees are made up.

Files
- org-chart.json: the Graph Modeler project.
- employee-data.xlsx: the data the project's SQL reads.
- org-chart-knowledge-graph.json: the Knowledge Graph of the diagram, as made by Graph Modeler 1.0.1 or later.

What to look at
- SQL tab: the placeholders at the top (id_number, max_down, max_up) and the TREE QUERY lines. Change id_number and choose Run SQL.
- Diagram tab and Knowledge Graph tab: the same data, as a picture and as JSON.
Keep the project and the spreadsheet in one folder, then choose Open in Graph Modeler.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
