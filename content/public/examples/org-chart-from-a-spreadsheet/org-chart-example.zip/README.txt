Org chart from a spreadsheet
============================
An organization chart centered on one employee, drawn with recursive queries. The employees are made up.

Files
- org-chart.json: the Graph Modeler project.
- employee-data.xlsx: the data the project's SQL reads.
- org-chart-knowledge-graph.json: the Knowledge Graph of the diagram, as made by Graph Modeler.

What to look at
- SQL tab: the placeholders at the top (id_number, max_down, max_up) and the two WITH RECURSIVE queries, one that walks down the reporting lines and one that walks up. Change id_number and choose Run SQL.
- Diagram tab and Knowledge Graph tab: the same data, as a picture and as JSON.
Keep the project and the spreadsheet in one folder, then choose Open in Graph Modeler.

The project uses WITH RECURSIVE, which needs Graph Modeler 1.1.0 or later. The same walk written with TREE QUERY, as the Excel tool wrote it, is described at https://graphmodeler.com/docs/sql-extensions/tree-query/.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
