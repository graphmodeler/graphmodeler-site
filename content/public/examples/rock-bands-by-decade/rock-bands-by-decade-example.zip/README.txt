Rock bands by decade and genre
==============================
131 rock bands in boxes: one box for each decade, from the 1960s to the 2010s, and inside it one box for each genre. The data was compiled by hand from publicly available information on bandtoband.com and typed into the spreadsheet. It is not an export or a mirror of that site's database, and the site is not affiliated with this example. It is test data for learning.

Files
- rock-bands-by-decade.json: the Graph Modeler project. Bands are circles colored by genre.
- musicians.xlsx: the data the project's SQL reads (a "band" sheet and a "genre" sheet, among others).
- rock-bands-by-decade-knowledge-graph.json: the Knowledge Graph of the All Styles view, as made by Graph Modeler 1.0.1 or later.

What to look at
- Settings tab: the layout engine is osage, which draws clusters as boxes and packs what is inside them.
- Styles tab: the "Page Cluster Begin" style has the pack mode array_tlu1, one column of decades; the decade and genre styles pack their contents into rows.
- SQL tab: one query makes the nodes, and puts each band in a cluster for its decade and a subcluster for its genre.
- Knowledge Graph tab: the decades and genres are clusters, and each band says which one it is in.
Keep the project and the spreadsheet in one folder, then choose Open in Graph Modeler.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
