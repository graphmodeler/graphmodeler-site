﻿London Underground: a diagram for every line
============================================
One model of the London Underground (stations, connections, districts and postcode areas) with a view for each line.

Files
- london-underground.json: the Graph Modeler project.
- London Underground Data.xlsx: the data the project's SQL reads.
- jubilee-knowledge-graph.json: the Knowledge Graph of the Jubilee view, as made by Graph Modeler 1.0.1 or later.

What to look at
- Diagram tab: choose a line in "Style view" in the left pane.
- Styles tab: each style is a row and each view a column (scroll right).
- SQL tab: the short queries that make the model.
Keep the project and the spreadsheet in one folder, then choose Open in Graph Modeler.

Data sources
- The data in this example was compiled by hand from publicly available information and entered into a spreadsheet. It is not an export or a mirror of any site's data, and the sites are not affiliated with this example. Data was last checked on 25-Nov-2024 and may no longer be current. Check the sources below for the most up-to-date information.

| Source                     | Topic                                                                                                    | 
| -------------------------- | ----------------------------------- | ------------------------------------------------------------------ | 
| Transport for London (TfL) | Tube map                            | https://content.tfl.gov.uk/standard-tube-map.pdf                   |
| Transport for London (TfL) | Stations, stops & piers             | https://tfl.gov.uk/travel-information/stations-stops-and-piers/    |
| Mapping London             | The Tube Map                        | https://mappinglondon.co.uk/2015/the-tube-map/                     |
| dannycox.me.uk             | Stations by line                    | https://tubephotos.dannycox.me.uk/stationsbyline.html              |
| dannycox.me.uk             | Station List                        | https://tubephotos.dannycox.me.uk/alphabeticalStationList.html     |
| Wikipedia                  | List of London Underground stations | https://en.wikipedia.org/wiki/List_of_London_Underground_stations/ |
| doogal.co.uk               | London Stations                     | https://www.doogal.co.uk/london_stations/                          |
| doogal.co.uk               | UK Postcodes                        | https://www.doogal.co.uk/UKPostcodes/                              |


Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
