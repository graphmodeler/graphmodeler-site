﻿London Underground: a diagram for every line
============================================
One model of the London Underground (stations, connections, districts and postcode areas) with a view for each line.

Files
- london-underground.json: the Graph Modeler project.
- London Underground Data.xlsx: the data the project's SQL reads.
- jubilee-knowledge-graph.json: the Knowledge Graph of the Jubilee view, as made by Graph Modeler 1.0.1 or later.

What to look at
- Diagram tab: choose a line in "Style view" in the left pane.
- Styles tab: each style is a row and each view a column (scroll right).
- SQL tab: the short queries that make the model.
Keep the project and the spreadsheet in one folder, then choose Open in Graph Modeler.

[DATA SOURCE AND LICENSE OF THE SPREADSHEET: TO BE FILLED IN BEFORE PUBLISHING]

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
