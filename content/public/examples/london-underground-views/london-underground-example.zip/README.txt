﻿London Underground example for Graph Modeler
============================================

One model of the London Underground network (about 550 stations and 500 connections) with a view for each line, so that one project
draws the Jubilee line, the Central line, or the Central line and the DLR together.

Files
- london-underground.json: the Graph Modeler project.
- London Underground Data.xlsx: the data the project's SQL reads.
- jubilee-knowledge-graph.json: the Knowledge Graph (JSON) of the Jubilee view, as made by the Knowledge Graph tab of Graph Modeler 1.0.1 or later.

How to open it
1. Keep the project and the spreadsheet together in one folder.
2. In Graph Modeler, choose Open and pick london-underground.json.
3. Choose a line in "Style view" in the left pane and look at the Diagram tab and the Knowledge Graph tab. On the SQL tab, Run SQL builds the rows again from the spreadsheet.

[DATA SOURCE AND LICENSE OF THE SPREADSHEET: TO BE FILLED IN BEFORE PUBLISHING]

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
The full write-up of this example: https://graphmodeler.com/examples/london-underground-views/
