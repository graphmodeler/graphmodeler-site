A kanban board drawn from a spreadsheet
=======================================
A kanban board of 49 tasks in three columns, To Do, Doing and Done, with a post-it note for each task, colored by the kind of work. The 50 tasks in the spreadsheet are made-up test data for learning; one of them has the status Archive, and the query leaves it out.

Files
- kanban.json: the Graph Modeler project.
- kanban.xlsx: the data the project's SQL reads (a "tasks" sheet and a "lists" sheet).
- kanban-knowledge-graph.json: the Knowledge Graph of the All Styles view, as made by Graph Modeler 1.0.1 or later.

What to look at
- Settings tab: the layout engine is osage, which draws clusters as boxes and packs what is inside them into rows and columns.
- Styles tab: the "Kanban Board Begin" and "Status Begin" styles have a pack mode, array_tu3 for the three columns and array_tu2 for two notes across a column. Each kind of work has a style with its fill and border colors.
- SQL tab: three queries, one for the board's title box, one for the notes, with the status as the cluster, and one for the legend.
Keep the project and the spreadsheet in one folder, then choose Open in Graph Modeler.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
