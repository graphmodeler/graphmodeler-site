﻿Order process, drawn by hand
============================
A flow diagram of an order process, typed into the Data tab row by row: no SQL and no spreadsheet behind it.

Files
- order-process.json: the Graph Modeler project.
- order-process-knowledge-graph.json: the Knowledge Graph of the diagram, as made by Graph Modeler 1.0.1 or later.

What to look at
- Data tab: the whole model is these rows. A row with an item is a node, a row with an item and a related item is an edge.
- Styles tab: Step, Decision and Store are node styles; Flow and Lookup are edge styles; Warehouse Begin and Warehouse End draw the box.
- The last row has the # flag, so it is a comment and is ignored.
Choose Open in Graph Modeler and pick order-process.json.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
