A timeline roadmap from a spreadsheet
=====================================
A roadmap of 20 made-up events from 2022 to 2030, drawn from two sheets: a timeline of events with a start and an end quarter, and a list of which events must finish before others can start. It is test data for learning.

Files
- timeline-roadmap.json: the Graph Modeler project.
- timeline.xlsx: the data the project's SQL reads (a "timeline" sheet and a "dependencies" sheet).
- timeline-roadmap-knowledge-graph.json: the Knowledge Graph of the All Styles view, as made by Graph Modeler 1.0.1 or later.

What to look at
- SQL tab: the steps build the roadmap one layer at a time. ENUMERATE makes a node for every year, even a year without an event, and chains them; one query draws each event as an edge from its start to its end, and another draws the dependencies.
- Styles tab: the status of an event (Completed, On Schedule, Planned, Behind Schedule) picks the edge's color; the Page Title style is the title.
- Settings tab: the layout engine is dot, left to right.
Keep the project and the spreadsheet in one folder, then choose Open in Graph Modeler.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
