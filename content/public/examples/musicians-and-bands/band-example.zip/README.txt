﻿Musicians and bands: a force-directed graph
===========================================
443 musicians and 131 rock bands, and the 627 connections between them. The data was compiled by hand from publicly available information on bandtoband.com and typed into
the spreadsheet. It is not an export or a mirror of that site's database, and the site is not affiliated with this example. It is test data for learning.

Files
- band-to-musician.json: the Graph Modeler project. The instruments are small shapes, one shape and color for each family: vocals (orange ellipse), guitars and bass (blue box), drums (red diamond), keyboards (purple hexagon), brass, woodwinds and harmonica (teal triangle), violin (green octagon). Bands are circles colored by genre.
- musicians.xlsx: the data the project's SQL reads.
- band-knowledge-graph.json: the Knowledge Graph of the All Styles view, as made by Graph Modeler 1.0.1 or later.

What to look at
- Settings tab: the graph engine is neato, a force-directed layout (the Diagram tab takes a few seconds).
- Knowledge Graph tab: the counts under the toolbar show the size and the estimated tokens.
Keep the project and the spreadsheet in one folder, then choose Open in Graph Modeler.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
