﻿System context diagram of a notifications application
=====================================================
A system context diagram of a hypothetical Consumer Notifications application, drawn from the Context Diagram Toolkit
(https://github.com/jjlong150/rv-kgf-context-diagram, MIT License). The data was seeded with errors on purpose.

Files
- context-diagram.json: the Graph Modeler project (converted from the toolkit's exchange file).
- context-diagram-knowledge-graph.json: the Knowledge Graph of the "Diagram" view, as made by Graph Modeler 1.0.1 or later.
- images/: the icons the styles refer to (Tabler Icons, MIT License; see images/README.md). Keep this folder next to the project.

What to look at
- Diagram tab: the views in "Style view" (with or without the legend, notes, clusters or edges).
- Styles tab: 163 styles, the kinds of thing and of connection, with their descriptions.
- Knowledge Graph tab: the same data as JSON.
The project holds the rows the toolkit's SQL produced, so it opens ready to draw. To run its SQL again, put the toolkit's "Context Diagram Data.xlsx" (in the toolkit's repository) in the same folder.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
