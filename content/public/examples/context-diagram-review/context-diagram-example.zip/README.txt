﻿System context diagram example for Graph Modeler
================================================

A system context diagram of a hypothetical Consumer Notifications application, drawn from the Context Diagram Toolkit for Relationship Visualizer
(https://github.com/jjlong150/rv-kgf-context-diagram, MIT License). The data was seeded with errors on purpose, so that an architecture review has something to find.

Files
- context-diagram.json: the Graph Modeler project (converted from the toolkit's exchange file).
- context-diagram-knowledge-graph.json: the Knowledge Graph (JSON) of the "Diagram" view, as made by the Knowledge Graph tab of Graph Modeler 1.0.1 or later.
- images/: the icons the styles refer to (Tabler Icons, MIT License; see images/README.md). Keep this folder next to the project.

How to open it
1. Keep the project and the images folder together in one folder.
2. In Graph Modeler, choose Open and pick context-diagram.json. The Diagram tab shows the diagram, and the Knowledge Graph tab the same data as JSON.
3. The project holds the rows the toolkit's SQL produced, so it opens ready to draw. To run the SQL again (Run SQL on the SQL tab), put the toolkit's
   "Context Diagram Data.xlsx" in the same folder; it is in the toolkit's repository, which also has the review prompt and the example's AI-written assessment report.

Graph Modeler: https://graphmodeler.com
Free for personal, educational, research and other non-commercial use; client or company work needs a commercial license (https://graphmodeler.com/pricing/).
The full write-up of this example: https://graphmodeler.com/examples/context-diagram-review/
